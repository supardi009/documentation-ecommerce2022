
	<footer style="border-top: 2px solid #DAA520;  ">
		

		<div class="copy" style="background-color: #DAA520; padding: 2px; color: #fff; text-align: center;">
			<span>Uji Komputer</span>
		</div>
	</footer>

</body>
</html>